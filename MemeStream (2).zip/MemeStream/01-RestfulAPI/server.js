import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("✅ MongoDB connected"))
.catch(err => console.error("❌ MongoDB error:", err));

// Meme Schema
const memeSchema = new mongoose.Schema({
  title: String,
  imageUrl: String,
  userId: String,
  createdAt: { type: Date, default: Date.now }
});

const Meme = mongoose.model("Meme", memeSchema);

// Routes
app.post("/memes", async (req, res) => {
  try {
    const meme = new Meme(req.body);
    await meme.save();
    res.status(201).json(meme);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get("/memes", async (req, res) => {
  try {
    const { userId } = req.query;
    const memes = userId ? await Meme.find({ userId }) : await Meme.find();
    res.json(memes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
